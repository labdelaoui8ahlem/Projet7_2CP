document.addEventListener("DOMContentLoaded", () => {
  const menuToggle = document.querySelector(".menu-toggle");
  const sidebar = document.getElementById("sidebar");
  const closeBtn = document.getElementById("closeBtn");
  const searchInput = document.querySelector(".search-box input");
  const startAnalysisBtn = document.querySelector(".start-analysis-btn");
  const mainContent = document.getElementById("main-content");
  const footer = document.querySelector("footer");

  const categories = {
    performance: document.getElementById("performanceList"),
    security: document.getElementById("securityList"),
    availability: document.getElementById("availabilityList"),
  };

  document.getElementById("pingecho-btn")?.addEventListener("click", () => {
    localStorage.setItem("analysisType", "pingecho");
  });

  document.getElementById("multiplecopies-btn")?.addEventListener("click", () => {
    localStorage.setItem("analysisType", "multiplecopies");
  });

  document.getElementById("ID-btn")?.addEventListener("click", () => {
    localStorage.setItem("analysisType", "id");
  });

  function updateEmptyMessages() {
    Object.values(categories).forEach((ul) => {
      if (!ul) return;
      const hasItems = ul.querySelectorAll("li.history-item").length > 0;
      const msg = ul.querySelector(".empty-msg");
      if (msg) msg.style.display = hasItems ? "none" : "block";
    });
  }

  function formatFileSize(size) {
    if (!size) return "Unknown size";
    const kb = size / 1024;
    return kb < 1024 ? `${kb.toFixed(2)} KB` : `${(kb / 1024).toFixed(2)} MB`;
  }

  function removeFromHistory(type, fileId) {
    const savedHistory = JSON.parse(localStorage.getItem("analysisHistory") || "{}");
    if (savedHistory[type]) {
      savedHistory[type] = savedHistory[type].filter(item => item.fileId !== fileId);
      localStorage.setItem("analysisHistory", JSON.stringify(savedHistory));
    }

    const list = categories[type];
    const item = list.querySelector(`[data-file-id="${fileId}"]`);
    if (item) {
      item.remove();
    }

    updateEmptyMessages();
  }

  function addToSidebar(type, filename, size, fileId, content) {
    let correctedType;
    const lowerType = type.toLowerCase();

    switch(lowerType) {
      case "pingecho":
        correctedType = "availability";
        break;
      case "multiplecopies":
        correctedType = "performance";
        break;
      case "id":
        correctedType = "security";
        break;
      case "performance":
      case "availability":
      case "security":
        correctedType = lowerType;
        break;
      default:
        console.error("Invalid tactic type:", type);
        return;
    }

    const list = categories[correctedType];
    if (!list) return;

    const existingItem = list.querySelector(`[data-file-id="${fileId}"]`);
    if (existingItem) {
      existingItem.remove();
    }

    const item = document.createElement("li");
    item.classList.add("history-item");
    item.setAttribute("data-file-id", fileId);

    const fileInfo = document.createElement("div");
    fileInfo.style.display = "flex";
    fileInfo.style.justifyContent = "space-between";
    fileInfo.style.width = "100%";

    const contentDiv = document.createElement("div");
    contentDiv.style.cursor = "pointer";

    const nameDiv = document.createElement("div");
    nameDiv.textContent = filename;

    const sizeDiv = document.createElement("div");
    sizeDiv.textContent = formatFileSize(size);

    const removeBtn = document.createElement("button");
    removeBtn.textContent = "×";
    removeBtn.classList.add("remove-btn");

    removeBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      removeFromHistory(correctedType, fileId);
    });

    contentDiv.appendChild(nameDiv);
    contentDiv.appendChild(sizeDiv);
    fileInfo.appendChild(contentDiv);
    fileInfo.appendChild(removeBtn);
    item.appendChild(fileInfo);

    contentDiv.addEventListener("click", () => {
      const savedHistory = JSON.parse(localStorage.getItem("analysisHistory") || "{}");
      const fileData = savedHistory[correctedType]?.find(item => item.fileId === fileId);

      if (fileData && fileData.content) {
fetch('http://localhost:8080/api/analyze', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            content: fileData.content,
            tactic: correctedType,
            fileId: fileId
          })
        })
        .then(response => response.json())
        .then(data => {
          localStorage.setItem("lastUploadedFileName", filename);
          localStorage.setItem("lastUploadedFileSize", size);
          localStorage.setItem("fileId", fileId);
          localStorage.setItem("analysisType", correctedType);
          localStorage.setItem("lastUploadedFileContent", fileData.content);
          localStorage.setItem("currentDetectionSummary", data.detectionSummary || "");

          window.location.href = `/result.html?fileId=${fileId}&tactic=${correctedType}&filename=${encodeURIComponent(filename)}`;
        })
        .catch(error => {
          console.error('Error:', error);
          alert('Error processing file. Please try again.');
        });
      }
    });

    list.insertBefore(item, list.firstChild);

    const savedHistory = JSON.parse(localStorage.getItem("analysisHistory") || "{}");
    if (!savedHistory[correctedType]) {
      savedHistory[correctedType] = [];
    }

    savedHistory[correctedType] = savedHistory[correctedType].filter(item => item.fileId !== fileId);

    savedHistory[correctedType].unshift({
      filename,
      size,
      fileId,
      content,
      timestamp: Date.now()
    });

    savedHistory[correctedType] = savedHistory[correctedType].slice(0, 10);
    localStorage.setItem("analysisHistory", JSON.stringify(savedHistory));
    updateEmptyMessages();
  }

  function loadHistoryFromStorage() {
    const savedHistory = JSON.parse(localStorage.getItem("analysisHistory") || "{}");

    for (const type in savedHistory) {
      const list = categories[type];
      if (!list) continue;

      const sortedHistory = savedHistory[type].sort((a, b) => b.timestamp - a.timestamp);

      sortedHistory.forEach(({ filename, size, fileId, content }) => {
        addToSidebar(type, filename, size, fileId, content);
      });
    }
  }

  if (searchInput) {
    searchInput.addEventListener("input", () => {
      const filter = searchInput.value.toLowerCase();
      Object.values(categories).forEach((ul) => {
        if (!ul) return;
        ul.querySelectorAll(".history-item").forEach((item) => {
          const text = item.textContent.toLowerCase();
          item.style.display = text.includes(filter) ? "block" : "none";
        });
      });
    });
  }

  if (startAnalysisBtn) {
    startAnalysisBtn.addEventListener("click", () => {
      const filename = localStorage.getItem("lastUploadedFileName");
      const size = parseInt(localStorage.getItem("lastUploadedFileSize"));
      const fileId = localStorage.getItem("fileId");
      const tactic = localStorage.getItem("analysisType");
      const content = localStorage.getItem("lastUploadedFileContent");

      if (filename && size && fileId && tactic && content) {
        fetch('/api/analyze', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            content: content,
            tactic: tactic,
            fileId: fileId
          })
        })
        .then(response => response.json())
        .then(data => {
          localStorage.setItem("currentDetectionSummary", data.detectionSummary || "");
          addToSidebar(tactic, filename, size, fileId, content);
        })
        .catch(error => {
          console.error('Error:', error);
          alert('Error processing file. Please try again.');
        });
      }
    });
  }

  if (menuToggle && sidebar && mainContent) {
    menuToggle.addEventListener("click", () => {
      sidebar.classList.add("active");
      mainContent.style.marginLeft = "250px";
      mainContent.style.width = "calc(100% - 250px)";
      if (footer) {
        footer.style.marginLeft = "250px";
        footer.style.width = "calc(100% - 250px)";
      }
    });
  }

  if (closeBtn && sidebar && mainContent) {
    closeBtn.addEventListener("click", () => {
      sidebar.classList.remove("active");
      mainContent.style.marginLeft = "100px";
      mainContent.style.width = "calc(100% - 100px)";
      if (footer) {
        footer.style.marginLeft = "100px";
        footer.style.width = "calc(100% - 100px)";
      }
    });
  }

  loadHistoryFromStorage();
  updateEmptyMessages();
});